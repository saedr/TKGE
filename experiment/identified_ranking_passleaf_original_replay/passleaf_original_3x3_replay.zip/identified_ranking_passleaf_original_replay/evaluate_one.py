#!/usr/bin/env python3
import argparse
import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
np.Inf = np.inf
np.in1d = np.isin

import torch


def add_unkr(path):
    sys.path.insert(0, str(Path(path) / "src"))


def read_rows(path):
    out = []
    with open(path, encoding="utf-8") as f:
        for row in csv.reader(f, delimiter="\t"):
            if len(row) >= 4:
                out.append((row[0], row[1], row[2], float(row[3])))
    return out


def strip_mapping_rows(s):
    s.train_triples = [x for x in s.train_triples if float(x[3]) > 0.5]
    s.hr2t_train = defaultdict(set)
    s.rt2h_train = defaultdict(set)
    s.h2rt_train = defaultdict(set)
    s.t2rh_train = defaultdict(set)
    s.hr2t_total = defaultdict(set)
    s.rt2h_total = defaultdict(set)
    s.all_true_triples = set(s.train_triples + s.valid_triples + s.test_triples)
    s.get_hr2t_rt2h_from_train()
    s.get_hr2t_rt2h_from_total()


def strong_queries(test_rows, tau=0.85, n=500):
    rows = sorted(test_rows, key=lambda x: (x[1], x[0], x[2]))
    q = rows[1::2]  # odd indices are Q in frozen PR13
    return [x for x in q if x[3] > tau][:n]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--unkr", required=True)
    ap.add_argument("--world-dir", required=True)
    ap.add_argument("--canonical-data", required=True)
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--world", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--device", choices=["cpu", "mps"], default="cpu")
    args = ap.parse_args()

    add_unkr(args.unkr)
    from unKR.utils import setup_parser, load_config, import_class

    cfg = setup_parser().parse_args([])
    cfg = load_config(cfg, str(Path(args.unkr) / "config/nl27k/PASSLEAF_nl27k.yaml"))
    cfg.data_path = str(Path(args.world_dir).resolve())
    cfg.gpu = args.device
    cfg.passleaf_score_function = "DistMult"
    cfg.seed = args.seed

    train_sampler = import_class(f"unKR.data.{cfg.train_sampler_class}")(cfg)
    strip_mapping_rows(train_sampler)

    model = import_class(f"unKR.model.{cfg.model_name}")(cfg)
    lit = import_class(f"unKR.lit_model.{cfg.litmodel_name}")(model, cfg)
    ck = torch.load(args.checkpoint, map_location=args.device, weights_only=False)
    lit.load_state_dict(ck["state_dict"])
    lit.eval()
    model = lit.model.to(args.device)

    canonical = Path(args.canonical_data)
    train_rows = read_rows(canonical / "train.tsv")
    val_rows = read_rows(canonical / "val.tsv")
    test_rows = read_rows(canonical / "test.tsv")
    queries = strong_queries(test_rows)
    if len(queries) != 500:
        raise RuntimeError(f"Expected 500 frozen strong Q queries, got {len(queries)}")

    # Fixed correctness filter from known strong facts, exactly as original pilot.
    tails_by_hr = defaultdict(set)
    for h, r, t, c in train_rows + val_rows + test_rows:
        if c > 0.85 and h in train_sampler.ent2id and r in train_sampler.rel2id and t in train_sampler.ent2id:
            tails_by_hr[(train_sampler.ent2id[h], train_sampler.rel2id[r])].add(train_sampler.ent2id[t])

    all_ent = model.ent_emb.weight
    results = []
    rr = []
    hits10 = []

    with torch.no_grad():
        for qi, (hs, rs, ts, conf) in enumerate(queries):
            h = train_sampler.ent2id[hs]
            r = train_sampler.rel2id[rs]
            t = train_sampler.ent2id[ts]

            hv = model.ent_emb.weight[h]
            rv = model.rel_emb.weight[r]
            raw = (hv * rv) @ all_ent.T
            scores = torch.sigmoid(model.w * raw + model.b)

            vals, ids = torch.topk(scores, 10)
            top_ids = ids.detach().cpu().tolist()
            top_scores = vals.detach().cpu().tolist()
            margin = float(top_scores[0] - top_scores[1])

            # Exact fixed-reference continuous margin for the crossed variance
            # decomposition: gold score minus the strongest non-gold score.
            gold_score_raw = float(scores[t].item())
            tmp = scores.clone()
            tmp[t] = -1.0
            best_alt_score_raw = float(tmp.max().item())
            gold_margin_raw = gold_score_raw - best_alt_score_raw

            fs = scores.clone()
            for other in tails_by_hr.get((h, r), ()):
                if other != t:
                    fs[other] = -1.0
            true_score = float(fs[t].item())
            rank = 1 + int((fs > true_score).sum().item())

            rr.append(1.0 / rank)
            hits10.append(rank <= 10)
            results.append({
                "query_index": qi,
                "head": hs,
                "relation": rs,
                "gold_tail": ts,
                "gold_confidence": conf,
                "h_id": h,
                "r_id": r,
                "gold_t_id": t,
                "top1_id": top_ids[0],
                "top1": train_sampler.id2ent[top_ids[0]],
                "top10_ids": top_ids,
                "top10": [train_sampler.id2ent[x] for x in top_ids],
                "top10_scores": top_scores,
                "margin_top1_top2": margin,
                "gold_score_raw": gold_score_raw,
                "best_alternative_score_raw": best_alt_score_raw,
                "gold_margin_raw": gold_margin_raw,
                "gold_rank_filtered": rank,
                "reciprocal_rank": 1.0 / rank,
                "hit10": bool(rank <= 10),
            })

    payload = {
        "world": args.world,
        "seed": args.seed,
        "checkpoint": args.checkpoint,
        "n_queries": len(results),
        "MRR": float(np.mean(rr)),
        "Hits@10": float(np.mean(hits10)),
        "queries": results,
    }
    Path(args.out).write_text(json.dumps(payload, indent=2))
    print(json.dumps({k: v for k, v in payload.items() if k != "queries"}, indent=2))


if __name__ == "__main__":
    main()
