#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-$PWD}"
DEVICE="${2:-cpu}"
EXP="$ROOT/experiment/identified_ranking_passleaf_original_replay"
PILOT="$EXP/_pinned_run_falsification.py"

if [ -d "$ROOT/unKR" ]; then
  UNKR="$ROOT/unKR"
elif [ -d "$ROOT/../unKR" ]; then
  UNKR="$(cd "$ROOT/../unKR" && pwd)"
else
  echo "ERROR: unKR not found at $ROOT/unKR or next to the repo at $ROOT/../unKR"
  exit 1
fi

CANON="$UNKR/dataset/nl27k"

if [ ! -f "$PILOT" ]; then
  echo "Downloading pinned PR #13 world-construction code..."
  curl -L --fail     "https://raw.githubusercontent.com/saedr/TKGE/771ff47cfe24df5ea28d6d22dc33ef05a6688a57/experiment/identified_ranking/run_falsification.py"     -o "$PILOT"
fi
WORK="$EXP/work"
RUNS="$EXP/runs"

mkdir -p "$EXP" "$WORK" "$RUNS"

echo "=== 1/3 Prepare exact PR13 LOWER/NOMINAL/UPPER worlds ==="
python3 "$EXP/prepare_worlds.py" \
  --pilot "$PILOT" \
  --canonical-data "$CANON" \
  --out "$WORK" \
  --device cpu

echo "=== 2/3 Train/evaluate crossed 3x3 PASSLEAF-DistMult ==="
for WORLD in LOWER NOMINAL UPPER; do
  for SEED in 11 23 37; do
    OUT="$RUNS/$WORLD/seed_$SEED"
    mkdir -p "$OUT"
    echo ">>> $WORLD seed=$SEED"
    if [ -f "$OUT/eval.json" ]; then
      echo "    complete; skipping"
      continue
    fi

    if [ ! -f "$OUT/train_result.json" ]; then
      python3 "$EXP/train_one.py" \
        --unkr "$UNKR" \
        --world-dir "$WORK/worlds/$WORLD" \
        --seed "$SEED" \
        --out "$OUT" \
        --device "$DEVICE"
    fi

    CKPT=$(python3 - "$OUT/train_result.json" <<'PY'
import json,sys
print(json.load(open(sys.argv[1]))["best_checkpoint"])
PY
)
    if [ ! -f "$CKPT" ]; then
      echo "ERROR: checkpoint listed in $OUT/train_result.json does not exist: $CKPT" >&2
      exit 2
    fi
    python3 "$EXP/evaluate_one.py" \
      --unkr "$UNKR" \
      --world-dir "$WORK/worlds/$WORLD" \
      --canonical-data "$CANON" \
      --checkpoint "$CKPT" \
      --seed "$SEED" \
      --world "$WORLD" \
      --out "$OUT/eval.json" \
      --device "$DEVICE"
  done
done

echo "=== 3/3 Analyze matched world vs seed effects ==="
python3 "$EXP/analyze_crossed.py" \
  --runs "$RUNS" \
  --out "$EXP/RESULT_3x3.json"

echo
echo "RESULT:"
cat "$EXP/RESULT_3x3.json"
