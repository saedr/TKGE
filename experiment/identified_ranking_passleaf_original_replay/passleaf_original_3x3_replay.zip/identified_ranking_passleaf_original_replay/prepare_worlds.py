#!/usr/bin/env python3
"""
Extract LOWER/NOMINAL/UPPER binary graph completions from the frozen PR #13
world-construction code without reimplementing that construction.

The frozen pilot's train_complex() is monkey-patched only after the worlds have
been constructed. The graph arguments are captured; no downstream ComplEx
training is performed. LOWER/UPPER are identified by graph size and NOMINAL by
its repeated use in the seed-control calls.
"""
import argparse
import csv
import hashlib
import importlib.util
import json
import shutil
from collections import Counter
from pathlib import Path

import numpy as np
import torch


def load_module(path):
    spec = importlib.util.spec_from_file_location("frozen_pilot", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def fingerprint(graph):
    arr = np.asarray(graph, dtype=np.int64)
    if arr.ndim != 2 or arr.shape[1] != 3:
        raise RuntimeError(f"Unexpected graph shape: {arr.shape}")
    arr = arr[np.lexsort((arr[:, 2], arr[:, 1], arr[:, 0]))]
    return hashlib.sha256(arr.tobytes()).hexdigest(), arr


def write_world(path, graph, id2e, id2r, all_entities, all_relations):
    path.mkdir(parents=True, exist_ok=True)
    out = path / "train.tsv"

    # Mapping-only sentinel prefix. unKR creates IDs in first-occurrence order.
    # These zero-confidence synthetic rows are removed from train_triples by
    # train_one.py before DataModule construction. Their sole purpose is to
    # force identical semantic entity/relation IDs in all nine runs.
    anchor_e = all_entities[0]
    anchor_r = all_relations[0]
    with out.open("w", encoding="utf-8") as f:
        for e in all_entities:
            f.write(f"{e}\t{anchor_r}\t{e}\t0.0\n")
        for r in all_relations[1:]:
            f.write(f"{anchor_e}\t{r}\t{anchor_e}\t0.0\n")
        for h, r, t in graph:
            f.write(f"{id2e[int(h)]}\t{id2r[int(r)]}\t{id2e[int(t)]}\t1.0\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pilot", required=True,
                    help="Path to PR13 experiment/identified_ranking/run_falsification.py")
    ap.add_argument("--out", required=True)
    ap.add_argument("--data-root", default=None,
                    help="PR13 data cache root. Default: sibling data under output work dir.")
    ap.add_argument("--canonical-data", required=True,
                    help="Original unKR dataset/nl27k directory; val/test are copied from here.")
    ap.add_argument("--device", default="cpu")
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    data_root = Path(args.data_root) if args.data_root else out / "pilot_data"
    dummy_results = out / "_capture_dummy"
    canonical = Path(args.canonical_data)

    # The frozen PR13 code downloads benchmark files only when they are absent.
    # Reuse the already-present local unKR NL27K files to avoid Python SSL/
    # certificate problems on managed macOS installations.
    local_cache = data_root / "nl27k"
    local_cache.mkdir(parents=True, exist_ok=True)
    for name in ("train.tsv", "val.tsv", "test.tsv", "softlogic.tsv"):
        src = canonical / name
        dst = local_cache / name
        if src.exists() and not dst.exists():
            shutil.copy2(src, dst)

    mod = load_module(Path(args.pilot))
    captured = []

    class Dummy:
        pass

    def capture_train(graph, nent, nrel, seed, cfg, device):
        fp, arr = fingerprint(graph)
        captured.append({"fp": fp, "arr": arr.copy(), "seed": int(seed)})
        return Dummy()

    def dummy_query(model, queries, nent, device, batch=64):
        n = len(queries)
        return (
            np.zeros(n, dtype=np.int64),
            np.zeros(n, dtype=np.float64),
            torch.zeros((n, nent), dtype=torch.float32),
        )

    def dummy_metrics(scores, queries, known_strong):
        n = len(queries)
        return 0.0, 0.0, [1] * n

    # Only downstream learner/evaluator are replaced. UKGE + conformal intervals +
    # split + world construction are the frozen PR13 implementation.
    mod.train_complex = capture_train
    mod.query_outputs = dummy_query
    mod.filtered_metrics = dummy_metrics

    mod.run_dataset("nl27k", data_root, dummy_results, args.device)

    if len(captured) < 3:
        raise RuntimeError(f"Captured only {len(captured)} graph calls.")

    counts = Counter(x["fp"] for x in captured)
    unique = {}
    for x in captured:
        unique.setdefault(x["fp"], x["arr"])

    lower_fp = min(unique, key=lambda k: len(unique[k]))
    upper_fp = max(unique, key=lambda k: len(unique[k]))
    repeated = [k for k, v in counts.items() if v > 1]
    if len(repeated) != 1:
        raise RuntimeError(
            f"Expected exactly one repeated graph (NOMINAL seed control), got {[(k, counts[k]) for k in repeated]}"
        )
    nominal_fp = repeated[0]
    if len({lower_fp, nominal_fp, upper_fp}) != 3:
        raise RuntimeError("LOWER/NOMINAL/UPPER did not resolve to three distinct graphs.")

    # Reconstruct the exact sorted semantic mapping used by PR13.
    train_s = mod.read_tsv(canonical / "train.tsv")
    val_s = mod.read_tsv(canonical / "val.tsv")
    test_s = mod.read_tsv(canonical / "test.tsv")
    soft_path = canonical / "softlogic.tsv"
    soft_s = mod.read_tsv(soft_path) if soft_path.exists() else []
    e2i, r2i = mod.build_mapping(train_s, val_s, test_s, soft_s)
    id2e = {v: k for k, v in e2i.items()}
    id2r = {v: k for k, v in r2i.items()}
    all_entities = [id2e[i] for i in range(len(id2e))]
    all_relations = [id2r[i] for i in range(len(id2r))]

    worlds = {
        "LOWER": unique[lower_fp],
        "NOMINAL": unique[nominal_fp],
        "UPPER": unique[upper_fp],
    }

    worlds_root = out / "worlds"
    for name, arr in worlds.items():
        wdir = worlds_root / name
        write_world(wdir, arr, id2e, id2r, all_entities, all_relations)
        shutil.copy2(canonical / "val.tsv", wdir / "val.tsv")
        shutil.copy2(canonical / "test.tsv", wdir / "test.tsv")
        if soft_path.exists():
            shutil.copy2(soft_path, wdir / "softlogic.tsv")

    meta = {
        "world_sizes": {k: int(len(v)) for k, v in worlds.items()},
        "captured_calls": len(captured),
        "unique_graphs": len(unique),
        "nominal_call_count": counts[nominal_fp],
        "entities": len(e2i),
        "relations": len(r2i),
        "conversion": "binary included graph fact -> PASSLEAF confidence 1.0",
        "mapping_prefix": "zero-confidence synthetic rows; stripped before training",
    }
    (out / "worlds_meta.json").write_text(json.dumps(meta, indent=2))
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
