#!/usr/bin/env python3
import argparse
import itertools
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
np.Inf = np.inf
np.in1d = np.isin
import torch

WORLDS = ["LOWER", "NOMINAL", "UPPER"]
SEEDS = [11, 23, 37]


def pair_mean(values):
    return float(np.mean(values)) if values else 0.0


def disagreement(a, b):
    return np.asarray(a) != np.asarray(b)


def anova_shares(x):
    # 3 worlds x 3 seeds, one cell each. Residual is world×seed interaction.
    x = np.asarray(x, dtype=float)
    g = x.mean()
    wr = x.mean(axis=1)
    sc = x.mean(axis=0)
    ss_w = x.shape[1] * np.sum((wr - g) ** 2)
    ss_s = x.shape[0] * np.sum((sc - g) ** 2)
    resid = x - wr[:, None] - sc[None, :] + g
    ss_i = np.sum(resid ** 2)
    total = ss_w + ss_s + ss_i
    if total <= 1e-15:
        return 0.0, 0.0, 0.0
    return float(ss_w/total), float(ss_s/total), float(ss_i/total)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    runs = Path(args.runs)
    data = {}
    for w in WORLDS:
        for s in SEEDS:
            p = runs / w / f"seed_{s}" / "eval.json"
            data[(w,s)] = json.loads(p.read_text())

    n = data[("NOMINAL",11)]["n_queries"]
    winners = {(w,s): [q["top1_id"] for q in d["queries"]] for (w,s),d in data.items()}

    # Matched aggregate disagreements.
    wd = []
    for s in SEEDS:
        for a,b in itertools.combinations(WORLDS,2):
            wd.append(float(np.mean(disagreement(winners[(a,s)], winners[(b,s)]))))
    sd = []
    for w in WORLDS:
        for a,b in itertools.combinations(SEEDS,2):
            sd.append(float(np.mean(disagreement(winners[(w,a)], winners[(w,b)]))))
    D_world = pair_mean(wd)
    D_seed = pair_mean(sd)

    query_rows = []
    world_share_flags = []
    reproducible_flags = []

    # We use a signed decision margin anchored at NOMINAL seed 11's winner.
    # To avoid storing 500x27221 score matrices, approximate candidate set by
    # the union of top-10 candidates observed across the nine runs. This contains
    # every observed winner and strong near competitors.
    for q in range(n):
        qwd = []
        per_seed_changed = []
        for s in SEEDS:
            vals = [winners[(w,s)][q] for w in WORLDS]
            pair = [vals[i] != vals[j] for i,j in itertools.combinations(range(3),2)]
            qwd.extend(pair)
            per_seed_changed.append(any(pair))

        qsd = []
        for w in WORLDS:
            vals = [winners[(w,s)][q] for s in SEEDS]
            qsd.extend(vals[i] != vals[j] for i,j in itertools.combinations(range(3),2))

        # Exact signed fixed-reference margin: gold-tail score minus strongest
        # alternative score. This is computed exactly in each evaluator run.
        margins = np.zeros((3,3), dtype=float)
        for wi,w in enumerate(WORLDS):
            for si,s in enumerate(SEEDS):
                margins[wi,si] = data[(w,s)]["queries"][q]["gold_margin_raw"]

        vw,vs,vi = anova_shares(margins)
        reproducible = sum(per_seed_changed) >= 2
        world20 = vw >= 0.20
        reproducible_flags.append(reproducible)
        world_share_flags.append(world20)

        query_rows.append({
            "query_index": q,
            "D_world_q": float(np.mean(qwd)),
            "D_seed_q": float(np.mean(qsd)),
            "delta_q": float(np.mean(qwd)-np.mean(qsd)),
            "world_changes_in_seeds": int(sum(per_seed_changed)),
            "reproducible_world_effect_2of3": reproducible,
            "variance_share_world": vw,
            "variance_share_seed": vs,
            "variance_share_interaction": vi,
            "world_share_ge_20pct": world20,
        })

    nominal = data[("NOMINAL",11)]
    result = {
        "design": "3 worlds x 3 seeds crossed PASSLEAF-DistMult",
        "worlds": WORLDS,
        "seeds": SEEDS,
        "n_queries": n,
        "WorldPairDisagree_matched": D_world,
        "SeedPairDisagree_matched": D_seed,
        "DeltaDisagree": D_world-D_seed,
        "fraction_queries_world_share_ge_20pct": float(np.mean(world_share_flags)),
        "fraction_queries_reproducible_world_effect_2of3": float(np.mean(reproducible_flags)),
        "nominal_seed11_MRR": nominal["MRR"],
        "nominal_seed11_Hits10": nominal["Hits@10"],
        "gates": {
            "delta_disagree_ge_0.10": bool(D_world-D_seed >= 0.10),
            "nominal_hits10_ge_0.20": bool(nominal["Hits@10"] >= 0.20),
        },
        "diagnostics": {
            "world_share_ge20_for_ge10pct_queries": bool(np.mean(world_share_flags) >= 0.10),
        },
        "query_level": query_rows,
    }
    result["CONTINUE"] = bool(
        result["gates"]["nominal_hits10_ge_0.20"]
        and result["gates"]["delta_disagree_ge_0.10"]
    )
    result["decision"] = "CONTINUE" if result["CONTINUE"] else "KILL"

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2))
    summary = {k:v for k,v in result.items() if k != "query_level"}
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
