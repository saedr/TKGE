#!/usr/bin/env python3
import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

# Compatibility aliases for old Lightning/unKR under NumPy 2.x.
np.Inf = np.inf
np.in1d = np.isin

import torch
import pytorch_lightning as pl
from pytorch_lightning import seed_everything


def add_unkr(path):
    src = Path(path) / "src"
    sys.path.insert(0, str(src))


def strip_mapping_rows(s):
    # Mapping sentinel rows have confidence 0.0; actual binary-world facts are 1.0.
    s.train_triples = [x for x in s.train_triples if float(x[3]) > 0.5]

    s.hr2t_train = defaultdict(set)
    s.rt2h_train = defaultdict(set)
    s.h2rt_train = defaultdict(set)
    s.t2rh_train = defaultdict(set)
    s.hr2t_total = defaultdict(set)
    s.rt2h_total = defaultdict(set)

    s.all_true_triples = set(s.train_triples + s.valid_triples + s.test_triples)
    s.get_hr2t_rt2h_from_train()
    s.get_hr2t_rt2h_from_total()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--unkr", required=True)
    ap.add_argument("--world-dir", required=True)
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--device", choices=["cpu", "mps"], default="cpu")
    args = ap.parse_args()

    add_unkr(args.unkr)
    from unKR.utils import setup_parser, load_config, import_class

    base_cfg = Path(args.unkr) / "config/nl27k/PASSLEAF_nl27k.yaml"
    cfg = setup_parser().parse_args([])
    cfg = load_config(cfg, str(base_cfg))
    cfg.data_path = str(Path(args.world_dir).resolve())
    cfg.dataset_name = "nl27k_crossed"
    cfg.seed = args.seed
    cfg.gpu = args.device
    cfg.confidence_filter = 0
    cfg.passleaf_score_function = "DistMult"

    seed_everything(cfg.seed)

    train_sampler_class = import_class(f"unKR.data.{cfg.train_sampler_class}")
    train_sampler = train_sampler_class(cfg)
    strip_mapping_rows(train_sampler)

    test_sampler_class = import_class(f"unKR.data.{cfg.test_sampler_class}")
    test_sampler = test_sampler_class(train_sampler)
    data_class = import_class(f"unKR.data.{cfg.data_class}")
    kgdata = data_class(cfg, train_sampler, test_sampler)

    model_class = import_class(f"unKR.model.{cfg.model_name}")
    model = model_class(cfg)
    litmodel_class = import_class(f"unKR.lit_model.{cfg.litmodel_name}")
    lit_model = litmodel_class(model, cfg)

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    ckpt = pl.callbacks.ModelCheckpoint(
        monitor="Eval_MAE",
        mode="min",
        save_top_k=1,
        filename="{epoch}-{Eval_MAE:.5f}",
        dirpath=str(out),
        save_weights_only=True,
    )
    early = pl.callbacks.EarlyStopping(
        monitor="Eval_MAE",
        mode="min",
        patience=cfg.early_stop_patience,
        check_on_train_epoch_end=False,
    )

    trainer_kwargs = dict(
        devices=1,
        max_epochs=cfg.max_epochs,
        check_val_every_n_epoch=cfg.check_val_every_n_epoch,
        callbacks=[ckpt, early],
        logger=False,
        default_root_dir=str(out),
        enable_progress_bar=True,
    )
    if args.device == "mps":
        trainer = pl.Trainer(accelerator="mps", **trainer_kwargs)
    else:
        trainer = pl.Trainer(accelerator="cpu", **trainer_kwargs)

    print(
        f"TRAIN world={Path(args.world_dir).name} seed={args.seed} "
        f"active_train={len(train_sampler.train_triples)} entities={cfg.num_ent} relations={cfg.num_rel}",
        flush=True,
    )
    trainer.fit(lit_model, datamodule=kgdata)

    result = {
        "seed": args.seed,
        "world": Path(args.world_dir).name,
        "best_checkpoint": ckpt.best_model_path,
        "checkpoint_monitor": "Eval_MAE",
        "best_validation_mae": None if ckpt.best_model_score is None else float(ckpt.best_model_score),
        "active_train": len(train_sampler.train_triples),
        "num_ent": cfg.num_ent,
        "num_rel": cfg.num_rel,
        "device": args.device,
    }
    (out / "train_result.json").write_text(json.dumps(result, indent=2))
    print("BEST_CHECKPOINT", ckpt.best_model_path, flush=True)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
